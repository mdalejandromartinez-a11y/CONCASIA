'use client'

import { useState, useEffect, useRef } from 'react'
import { motion, useInView, AnimatePresence } from 'framer-motion'
import {
  Shield, CheckCircle2, Award, ClipboardCheck, HeartPulse, BookOpen,
  Phone, Mail, MapPin, ChevronDown, Menu, X, ArrowRight,
  FileText, Users, AlertTriangle, Stethoscope, GraduationCap,
  Building2, Factory, UtensilsCrossed, School, Hospital, Store,
  Landmark, Briefcase, Search, Target, Cog, PenTool, UserCheck,
  FileCheck, Wrench, TrendingUp, Handshake, Eye, Lock, Leaf,
  Sparkles, ChevronUp, MessageCircle, Star, Zap, BadgeCheck,
  ShieldCheck, FileBarChart, HardHat, Microscope, FlaskConical,
  Apple, ClipboardList, AlertCircle, CheckSquare, ArrowUpRight,
  Gavel, Activity, Heart, Droplets, Flame, Monitor, Trophy
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

/* ────────────────────────────── Animation helpers ────────────────────────────── */

function FadeInWhenVisible({ children, delay = 0, direction = 'up', className }: { children: React.ReactNode; delay?: number; direction?: 'up' | 'down' | 'left' | 'right'; className?: string }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-60px' })

  const directionOffset = {
    up: { y: 40 },
    down: { y: -40 },
    left: { x: 40 },
    right: { x: -40 },
  }

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, ...directionOffset[direction] }}
      animate={isInView ? { opacity: 1, x: 0, y: 0 } : { opacity: 0, ...directionOffset[direction] }}
      transition={{ duration: 0.6, delay, ease: 'easeOut' }}
      className={className}
    >
      {children}
    </motion.div>
  )
}

function StaggerContainer({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <motion.div
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: '-60px' }}
      variants={{
        hidden: {},
        visible: { transition: { staggerChildren: 0.1 } },
      }}
      className={className}
    >
      {children}
    </motion.div>
  )
}

function StaggerItem({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 30 },
        visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' } },
      }}
      className={className}
    >
      {children}
    </motion.div>
  )
}

/* ────────────────────────────── HEADER ────────────────────────────── */

function Header() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const navLinks = [
    { href: '#inicio', label: 'Inicio' },
    { href: '#nosotros', label: 'Nosotros' },
    { href: '#servicios', label: 'Servicios' },
    { href: '#sistemas-gestion', label: 'Sistemas de Gestión' },
    { href: '#seguridad-salud', label: 'Seguridad y Salud' },
    { href: '#medicina', label: 'Medicina Ocupacional' },
    { href: '#capacitaciones', label: 'Capacitaciones' },
    { href: '#contacto', label: 'Contacto' },
  ]

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/95 backdrop-blur-md shadow-lg border-b border-gray-100'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <a href="#inicio" className="flex items-center gap-3 group">
            <img
              src="/concasia-logo.png"
              alt="CONCASIA - Consultoría en Sistemas de Gestión, Seguridad y Salud Ocupacional"
              className="h-9 lg:h-11 w-auto object-contain transition-transform group-hover:scale-105"
            />
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden xl:flex items-center gap-1">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className={`px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                  isScrolled
                    ? 'text-gray-700 hover:text-[#1e3a5f] hover:bg-blue-50'
                    : 'text-white/90 hover:text-white hover:bg-white/10'
                }`}
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* CTA Button */}
          <div className="hidden xl:flex items-center gap-3">
            <a
              href="#contacto"
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#2d8a4e] hover:bg-[#1e6b38] text-white text-sm font-semibold rounded-lg transition-all duration-200 shadow-md hover:shadow-lg"
            >
              <Phone className="w-4 h-4" />
              Solicitar asesoría
            </a>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className={`xl:hidden p-2 rounded-lg transition-colors ${
              isScrolled ? 'text-gray-700 hover:bg-gray-100' : 'text-white hover:bg-white/10'
            }`}
            aria-label="Abrir menú de navegación"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="xl:hidden bg-white border-t border-gray-100 shadow-lg"
          >
            <div className="px-4 py-4 space-y-1">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block px-4 py-3 text-gray-700 hover:text-[#1e3a5f] hover:bg-blue-50 rounded-lg text-sm font-medium transition-colors"
                >
                  {link.label}
                </a>
              ))}
              <div className="pt-3 border-t border-gray-100">
                <a
                  href="#contacto"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="flex items-center justify-center gap-2 px-5 py-3 bg-[#2d8a4e] hover:bg-[#1e6b38] text-white text-sm font-semibold rounded-lg transition-colors"
                >
                  <Phone className="w-4 h-4" />
                  Solicitar asesoría
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  )
}

/* ────────────────────────────── HERO ────────────────────────────── */

function Hero() {
  return (
    <section id="inicio" className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src="/hero-bg.png"
          alt="Equipo consultor profesional en sistemas de gestión y seguridad ocupacional"
          className="w-full h-full object-cover"
        />
        <div className="hero-overlay absolute inset-0" />
      </div>

      {/* Decorative shapes */}
      <div className="absolute top-20 right-0 w-96 h-96 bg-white/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-[#2d8a4e]/10 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 lg:py-40">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm border border-white/20 text-white/90 text-sm font-medium rounded-full mb-6">
              <Sparkles className="w-4 h-4" />
              Consultoría especializada para su empresa
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.15 }}
            className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6"
          >
            Soluciones integrales en{' '}
            <span className="text-[#4ade80]">sistemas de gestión</span>, seguridad laboral, inocuidad alimentaria y medicina ocupacional
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="text-lg sm:text-xl text-white/85 mb-8 leading-relaxed max-w-2xl"
          >
            Acompañamos a su empresa con consultoría técnica, capacitación y auditoría especializada para cumplir la normativa vigente, proteger a sus trabajadores y optimizar sus procesos de gestión. Desde la implementación de normas ISO hasta la preparación para auditorías ministeriales, somos su aliado estratégico.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.45 }}
            className="flex flex-col sm:flex-row gap-4"
          >
            <a
              href="#contacto"
              className="inline-flex items-center justify-center gap-2 px-7 py-4 bg-[#2d8a4e] hover:bg-[#1e6b38] text-white font-semibold rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl text-base"
            >
              <ClipboardCheck className="w-5 h-5" />
              Solicitar diagnóstico empresarial
            </a>
            <a
              href="https://wa.me/593985801065"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-7 py-4 bg-white/10 hover:bg-white/20 backdrop-blur-sm border border-white/30 text-white font-semibold rounded-xl transition-all duration-200 text-base"
            >
              <MessageCircle className="w-5 h-5" />
              Hablar con un asesor
            </a>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="mt-14 grid grid-cols-3 gap-6 max-w-lg"
          >
            {[
              { number: '15+', label: 'Años de experiencia' },
              { number: 'Nº1', label: 'Resolución de problemas' },
              { number: 'ISO 9001', label: 'Implementación' },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-2xl font-bold text-[#4ade80]">{stat.number}</div>
                <div className="text-sm text-white/70 mt-1">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <a href="#nosotros" className="flex flex-col items-center gap-2 text-white/60 hover:text-white/80 transition-colors">
          <span className="text-xs font-medium">Descubra más</span>
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            <ChevronDown className="w-5 h-5" />
          </motion.div>
        </a>
      </motion.div>
    </section>
  )
}

/* ────────────────────────────── ABOUT ────────────────────────────── */

function About() {
  const values = [
    { icon: <ShieldCheck className="w-6 h-6" />, title: 'Responsabilidad técnica', desc: 'Cada intervención se fundamenta en criterios técnicos rigurosos y documentación respaldada por la normativa vigente.' },
    { icon: <Award className="w-6 h-6" />, title: 'Ética profesional', desc: 'Actuamos con integridad, transparencia y respeto en cada relación con nuestros clientes y colaboradores.' },
    { icon: <ClipboardList className="w-6 h-6" />, title: 'Cumplimiento normativo', desc: 'Garantizamos que cada proceso y documento se alinee con los requisitos legales y estándares aplicables.' },
    { icon: <TrendingUp className="w-6 h-6" />, title: 'Mejora continua', desc: 'Promovemos la cultura de la mejora permanente como eje del crecimiento organizacional y la excelencia operativa.' },
    { icon: <Lock className="w-6 h-6" />, title: 'Confidencialidad', desc: 'Protegemos la información sensible de nuestros clientes con los más altos estándares de discreción y seguridad.' },
    { icon: <Heart className="w-6 h-6" />, title: 'Compromiso con la seguridad y salud laboral', desc: 'Colocamos la protección de los trabajadores como prioridad absoluta en cada proyecto y recomendación.' },
    { icon: <Eye className="w-6 h-6" />, title: 'Enfoque preventivo', desc: 'Anticipamos riesgos y diseñamos estrategias preventivas que evitan incidentes antes de que ocurran.' },
  ]

  return (
    <section id="nosotros" className="py-20 lg:py-28 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image */}
          <FadeInWhenVisible direction="left">
            <div className="relative">
              <div className="absolute -top-4 -left-4 w-full h-full bg-[#1e3a5f]/5 rounded-2xl" />
              <img
                src="/about-img.png"
                alt="Consultor profesional de CONCASIA en instalación industrial evaluando seguridad ocupacional"
                className="relative rounded-2xl shadow-xl w-full h-[500px] object-cover"
              />
              <div className="absolute -bottom-6 -right-6 bg-[#2d8a4e] text-white p-6 rounded-2xl shadow-lg hidden sm:block">
                <div className="text-3xl font-bold">+15</div>
                <div className="text-sm text-white/80">Años de experiencia</div>
              </div>
            </div>
          </FadeInWhenVisible>

          {/* Content */}
          <FadeInWhenVisible direction="right" delay={0.2}>
            <div>
              <span className="inline-flex items-center gap-2 text-[#2d8a4e] font-semibold text-sm uppercase tracking-wider mb-4">
                <Building2 className="w-4 h-4" />
                Quiénes somos
              </span>
              <h2 className="text-3xl lg:text-4xl font-bold text-[#1e3a5f] mb-6 leading-tight">
                Su aliado estratégico en consultoría empresarial y cumplimiento normativo
              </h2>
              <p className="text-gray-600 text-lg leading-relaxed mb-8">
                CONCASIA es una empresa consultora con más de 15 años de experiencia, especializada en brindar acompañamiento técnico integral a organizaciones que buscan cumplir con las normativas vigentes, mejorar sus procesos internos, prevenir riesgos laborales y fortalecer su gestión organizacional. Somos líderes en resolución de problemas en el país, con experiencia comprobada en empresas de servicios hoteleros, petroleros, ambientales, catering, software y más. Nuestro equipo de profesionales combina experiencia técnica, conocimiento normativo y un compromiso genuino con la seguridad y salud de los trabajadores para entregar soluciones que realmente funcionan en el día a día de su empresa.
              </p>
              <p className="text-gray-600 leading-relaxed mb-10">
                Desde la implementación de sistemas de gestión basados en normas ISO hasta la gestión de seguridad y salud ocupacional, inocuidad alimentaria y medicina ocupacional, en CONCASIA trabajamos de la mano con cada cliente para diseñar estrategias adaptadas a su industria, tamaño y necesidades específicas. Nuestra trayectoria nos respalda: hemos acompañado exitosamente a empresas de los sectores hotelero, petrolero, ambiental, catering y de software, resolviendo los desafíos más complejos y posicionándonos como la consultora de referencia en el Ecuador. Nuestra meta es que su empresa no solo cumpla la ley, sino que se convierta en un referente de excelencia operativa y responsabilidad corporativa.
              </p>

              {/* Mission & Vision */}
              <div className="grid sm:grid-cols-2 gap-6 mb-10">
                <div className="bg-[#1e3a5f]/5 rounded-xl p-6 border border-[#1e3a5f]/10">
                  <h3 className="text-lg font-bold text-[#1e3a5f] mb-3 flex items-center gap-2">
                    <Target className="w-5 h-5 text-[#2d8a4e]" />
                    Misión
                  </h3>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    Brindar soluciones integrales de consultoría, capacitación y auditoría que permitan a las organizaciones cumplir con la normativa vigente, proteger a sus trabajadores, optimizar sus procesos y alcanzar la excelencia en su gestión operativa y administrativa.
                  </p>
                </div>
                <div className="bg-[#2d8a4e]/5 rounded-xl p-6 border border-[#2d8a4e]/10">
                  <h3 className="text-lg font-bold text-[#1e3a5f] mb-3 flex items-center gap-2">
                    <Eye className="w-5 h-5 text-[#2d8a4e]" />
                    Visión
                  </h3>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    Ser la empresa consultora líder y referente en sistemas de gestión, seguridad y salud ocupacional e inocuidad alimentaria, reconocida por la calidad técnica de sus servicios, su liderazgo en resolución de problemas, su compromiso con la prevención y su impacto positivo en las organizaciones del Ecuador.
                  </p>
                </div>
              </div>
            </div>
          </FadeInWhenVisible>
        </div>

        {/* Values */}
        <FadeInWhenVisible delay={0.3}>
          <div className="mt-20">
            <h3 className="text-2xl lg:text-3xl font-bold text-[#1e3a5f] text-center mb-4">Nuestros valores</h3>
            <p className="text-gray-600 text-center max-w-2xl mx-auto mb-12">
              Los principios que guían cada una de nuestras acciones y definen nuestro compromiso con la excelencia y la responsabilidad profesional.
            </p>
            <StaggerContainer className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7 gap-4">
              {values.map((v) => (
                <StaggerItem key={v.title}>
                  <div className="bg-white border border-gray-100 rounded-xl p-5 text-center hover:shadow-lg hover:border-[#2d8a4e]/30 transition-all duration-300 group h-full">
                    <div className="w-12 h-12 bg-[#2d8a4e]/10 text-[#2d8a4e] rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:bg-[#2d8a4e] group-hover:text-white transition-colors duration-300">
                      {v.icon}
                    </div>
                    <h4 className="font-semibold text-[#1e3a5f] text-sm mb-2">{v.title}</h4>
                    <p className="text-xs text-gray-500 leading-relaxed">{v.desc}</p>
                  </div>
                </StaggerItem>
              ))}
            </StaggerContainer>
          </div>
        </FadeInWhenVisible>
      </div>
    </section>
  )
}

/* ────────────────────────────── SERVICES ────────────────────────────── */

const services = [
  {
    id: 'sistemas-gestion',
    icon: <Award className="w-7 h-7" />,
    title: 'Sistemas de Gestión y Calidad',
    shortDesc: 'Implementación de normas ISO 9001, diseño de sistemas de gestión y preparación para auditorías.',
    color: '#1e3a5f',
    bgColor: '#1e3a5f/10',
    items: [
      { icon: <FileText className="w-5 h-5" />, text: 'Implementación completa de normas ISO 9001 con enfoque en resultados medibles y mejora continua.' },
      { icon: <Cog className="w-5 h-5" />, text: 'Diseño y optimización de sistemas de gestión adaptados a la estructura, tamaño y actividad de cada organización.' },
      { icon: <ClipboardCheck className="w-5 h-5" />, text: 'Auditoría y gestión de procesos con metodologías probadas que identifican oportunidades de mejora reales.' },
      { icon: <UserCheck className="w-5 h-5" />, text: 'Seguimiento técnico especializado durante todas las etapas de implementación y mantenimiento del sistema.' },
      { icon: <Search className="w-5 h-5" />, text: 'Preparación estratégica para auditorías internas, externas y ministeriales con simulacros y revisión documental.' },
      { icon: <PenTool className="w-5 h-5" />, text: 'Elaboración de documentación técnica: matrices, procedimientos, instructivos, registros e indicadores de gestión.' },
      { icon: <TrendingUp className="w-5 h-5" />, text: 'Acompañamiento en procesos de mejora continua para sostener y elevar los estándares de calidad alcanzados.' },
    ],
  },
  {
    id: 'inocuidad',
    icon: <Apple className="w-7 h-7" />,
    title: 'Inocuidad Alimentaria',
    shortDesc: 'Implementación de BPA, HACCP y control de riesgos de contaminación en la cadena alimentaria.',
    color: '#2d8a4e',
    bgColor: '#2d8a4e/10',
    items: [
      { icon: <BadgeCheck className="w-5 h-5" />, text: 'Implementación de Buenas Prácticas Alimenticias adaptadas al tipo de establecimiento y proceso productivo.' },
      { icon: <FlaskConical className="w-5 h-5" />, text: 'Implementación de sistemas HACCP con análisis de peligros y puntos críticos de control documentados.' },
      { icon: <Search className="w-5 h-5" />, text: 'Diagnóstico de procesos alimentarios para identificar riesgos, brechas y oportunidades de mejora sanitaria.' },
      { icon: <FileText className="w-5 h-5" />, text: 'Elaboración de manuales, procedimientos y registros de inocuidad según normativa vigente y estándares internacionales.' },
      { icon: <GraduationCap className="w-5 h-5" />, text: 'Capacitación al personal manipulador de alimentos en higiene, manejo seguro y prevención de contaminación.' },
      { icon: <AlertTriangle className="w-5 h-5" />, text: 'Control de riesgos de contaminación física, química y biológica a lo largo de toda la cadena productiva.' },
      { icon: <ShieldCheck className="w-5 h-5" />, text: 'Verificación de cumplimiento sanitario frente a normativas locales y requerimientos de organismos de control.' },
      { icon: <ClipboardCheck className="w-5 h-5" />, text: 'Auditorías internas de inocuidad alimentaria con informes detallados y planes de acción correctiva.' },
    ],
  },
  {
    id: 'seguridad-salud',
    icon: <HardHat className="w-7 h-7" />,
    title: 'Seguridad y Salud Ocupacional',
    shortDesc: 'Reglamentos internos, planes de emergencia, gestión de riesgos laborales y preparación para auditorías.',
    color: '#b45309',
    bgColor: '#b45309/10',
    items: [
      { icon: <FileText className="w-5 h-5" />, text: 'Elaboración integral de reglamentos internos de higiene y seguridad laboral conforme a la legislación vigente.' },
      { icon: <AlertTriangle className="w-5 h-5" />, text: 'Diseño y ejecución de planes de emergencia y contingencia con protocolos claros y simulacros periódicos.' },
      { icon: <Shield className="w-5 h-5" />, text: 'Gestión de riesgos laborales con metodologías estructuradas para identificar, evaluar y controlar peligros.' },
      { icon: <Search className="w-5 h-5" />, text: 'Identificación de peligros y evaluación de riesgos en cada puesto y área de trabajo de su organización.' },
      { icon: <ClipboardList className="w-5 h-5" />, text: 'Elaboración de matrices de riesgos actualizadas y priorizadas para una gestión preventiva efectiva.' },
      { icon: <ShieldCheck className="w-5 h-5" />, text: 'Programas de prevención de accidentes y enfermedades ocupacionales con seguimiento y medición de indicadores.' },
      { icon: <GraduationCap className="w-5 h-5" />, text: 'Capacitación continua en salud y seguridad industrial adaptada a los riesgos específicos de cada empresa.' },
      { icon: <Heart className="w-5 h-5" />, text: 'Programas de promoción y prevención en el ámbito laboral que fortalecen la cultura de autocuidado.' },
      { icon: <Gavel className="w-5 h-5" />, text: 'Preparación para inspecciones y auditorías del Ministerio del Trabajo con documentación completa y organizada.' },
    ],
  },
  {
    id: 'organismos',
    icon: <Landmark className="w-7 h-7" />,
    title: 'Gestión ante Organismos de Control',
    shortDesc: 'Seguimiento técnico ante el Ministerio del Trabajo, preparación documental y acompañamiento en inspecciones.',
    color: '#7c3aed',
    bgColor: '#7c3aed/10',
    items: [
      { icon: <UserCheck className="w-5 h-5" />, text: 'Seguimiento técnico especializado de OECS y OCCS ante el Ministerio del Trabajo con reportes periódicos.' },
      { icon: <Handshake className="w-5 h-5" />, text: 'Asesoría para cumplimiento de obligaciones laborales y de seguridad que eviten observaciones y sanciones.' },
      { icon: <FileCheck className="w-5 h-5" />, text: 'Preparación documental para auditorías ministeriales con revisión exhaustiva de cada requisito legal.' },
      { icon: <Search className="w-5 h-5" />, text: 'Revisión de evidencias, registros, planes, matrices y reportes para asegurar su integridad y completitud.' },
      { icon: <Users className="w-5 h-5" />, text: 'Acompañamiento técnico durante procesos de control o inspección de organismos gubernamentales.' },
      { icon: <Shield className="w-5 h-5" />, text: 'Gestión estratégica para evitar incumplimientos, observaciones o sanciones que afecten la operación de su empresa.' },
    ],
  },
  {
    id: 'medicina',
    icon: <Stethoscope className="w-7 h-7" />,
    title: 'Medicina Ocupacional',
    shortDesc: 'Servicios médicos ocupacionales, evaluaciones, vigilancia de la salud y programas de prevención.',
    color: '#dc2626',
    bgColor: '#dc2626/10',
    items: [
      { icon: <Stethoscope className="w-5 h-5" />, text: 'Servicio de medicina ocupacional con enfoque preventivo y cumplimiento de los requisitos legales aplicables.' },
      { icon: <ClipboardList className="w-5 h-5" />, text: 'Elaboración y seguimiento de fichas médicas ocupacionales con historial completo de cada trabajador.' },
      { icon: <Activity className="w-5 h-5" />, text: 'Gestión para exámenes de laboratorio conforme a los perfiles de riesgo de cada puesto de trabajo.' },
      { icon: <HeartPulse className="w-5 h-5" />, text: 'Evaluaciones médicas ocupacionales de ingreso, periódicas y de reintegro con criterios técnicos rigurosos.' },
      { icon: <UserCheck className="w-5 h-5" />, text: 'Seguimiento médico de trabajadores con condiciones de salud que requieren atención o restricciones especiales.' },
      { icon: <Apple className="w-5 h-5" />, text: 'Manejo oportuno de problemas nutricionales que pueden afectar el desempeño y bienestar del personal.' },
      { icon: <Heart className="w-5 h-5" />, text: 'Programas de promoción y prevención en salud laboral que fomentan hábitos saludables y autocuidado.' },
      { icon: <Shield className="w-5 h-5" />, text: 'Planes pandémicos con protocolos de actuación, prevención y respuesta ante emergencias sanitarias.' },
      { icon: <Eye className="w-5 h-5" />, text: 'Vigilancia de la salud de los trabajadores mediante indicadores y análisis de tendencias de morbilidad.' },
      { icon: <GraduationCap className="w-5 h-5" />, text: 'Capacitaciones en salud ocupacional, prevención de enfermedades y autocuidado para todos los niveles de la organización.' },
    ],
  },
  {
    id: 'capacitaciones',
    icon: <GraduationCap className="w-7 h-7" />,
    title: 'Capacitación Empresarial',
    shortDesc: 'Formación práctica en seguridad industrial, ISO, HACCP, gestión de riesgos y cumplimiento normativo.',
    color: '#0891b2',
    bgColor: '#0891b2/10',
    items: [
      { icon: <HardHat className="w-5 h-5" />, text: 'Capacitaciones continuas en salud y seguridad industrial con contenido práctico y aplicable al puesto de trabajo.' },
      { icon: <Award className="w-5 h-5" />, text: 'Capacitación en ISO 9001 para equipos que implementan, mantienen o auditan sistemas de gestión de la calidad.' },
      { icon: <Apple className="w-5 h-5" />, text: 'Capacitación en Buenas Prácticas Alimenticias dirigida a manipuladores y supervisores de alimentos.' },
      { icon: <FlaskConical className="w-5 h-5" />, text: 'Capacitación en HACCP con enfoque en la identificación y control de peligros en la cadena alimentaria.' },
      { icon: <AlertTriangle className="w-5 h-5" />, text: 'Capacitación en gestión de riesgos laborales para comités de seguridad y personal operativo.' },
      { icon: <Shield className="w-5 h-5" />, text: 'Capacitación en planes de emergencia y contingencia con simulacros y protocolos de evacuación.' },
      { icon: <Users className="w-5 h-5" />, text: 'Formación de brigadas de emergencia, primeros auxilios, evacuación y combate de incendios.' },
      { icon: <Heart className="w-5 h-5" />, text: 'Charlas de prevención y promoción de salud para fortalecer la cultura de autocuidado en la organización.' },
      { icon: <ClipboardCheck className="w-5 h-5" />, text: 'Entrenamientos prácticos para auditorías y cumplimiento normativo que preparan al equipo ante inspecciones reales.' },
    ],
  },
]

function Services() {
  return (
    <section id="servicios" className="py-20 lg:py-28 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <FadeInWhenVisible>
          <div className="text-center mb-16">
            <span className="inline-flex items-center gap-2 text-[#2d8a4e] font-semibold text-sm uppercase tracking-wider mb-4">
              <Cog className="w-4 h-4" />
              Nuestros servicios
            </span>
            <h2 className="text-3xl lg:text-4xl font-bold text-[#1e3a5f] mb-6">
              Soluciones especializadas para cada necesidad de su empresa
            </h2>
            <p className="text-gray-600 text-lg max-w-3xl mx-auto leading-relaxed">
              Ofrecemos un portafolio completo de servicios de consultoría, auditoría y capacitación diseñados para que su organización cumpla la normativa, proteja a su personal y mejore continuamente sus procesos. Cada servicio se adapta a su industria, tamaño y objetivos específicos.
            </p>
          </div>
        </FadeInWhenVisible>

        <StaggerContainer className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <StaggerItem key={service.id}>
              <a href={`#${service.id}`}>
                <div className="service-card bg-white rounded-2xl border border-gray-100 p-6 lg:p-8 h-full cursor-pointer group">
                  <div
                    className="w-14 h-14 rounded-xl flex items-center justify-center mb-5 transition-colors duration-300"
                    style={{ backgroundColor: `${service.color}15`, color: service.color }}
                  >
                    {service.icon}
                  </div>
                  <h3 className="text-xl font-bold text-[#1e3a5f] mb-3 group-hover:text-[#2d8a4e] transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 text-sm leading-relaxed mb-4">
                    {service.shortDesc}
                  </p>
                  <span className="inline-flex items-center gap-1 text-sm font-medium transition-colors" style={{ color: service.color }}>
                    Conocer más <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </span>
                </div>
              </a>
            </StaggerItem>
          ))}
        </StaggerContainer>
      </div>
    </section>
  )
}

/* ────────────────────────────── SERVICE DETAIL SECTIONS ────────────────────────────── */

function ServiceDetailSection({ service }: { service: typeof services[0] }) {
  return (
    <section id={service.id} className="py-20 lg:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-5 gap-12 lg:gap-16">
          {/* Sidebar info */}
          <FadeInWhenVisible direction="left" className="lg:col-span-2">
            <div className="sticky top-28">
              <div
                className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6"
                style={{ backgroundColor: `${service.color}15`, color: service.color }}
              >
                {service.icon}
              </div>
              <h2 className="text-3xl lg:text-4xl font-bold text-[#1e3a5f] mb-4 leading-tight">
                {service.title}
              </h2>
              <p className="text-gray-600 text-lg leading-relaxed mb-8">
                {service.shortDesc}
              </p>
              <a
                href="#contacto"
                className="inline-flex items-center gap-2 px-6 py-3 text-white font-semibold rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl"
                style={{ backgroundColor: service.color }}
              >
                <Phone className="w-5 h-5" />
                Solicitar asesoría
              </a>
            </div>
          </FadeInWhenVisible>

          {/* Items */}
          <FadeInWhenVisible direction="right" delay={0.2} className="lg:col-span-3">
            <div className="space-y-4">
              {service.items.map((item, idx) => (
                <div
                  key={idx}
                  className="flex gap-4 p-5 bg-gray-50 rounded-xl border border-gray-100 hover:shadow-md transition-all duration-300 group"
                >
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0 transition-colors"
                    style={{ backgroundColor: `${service.color}10`, color: service.color }}
                  >
                    {item.icon}
                  </div>
                  <p className="text-gray-700 leading-relaxed pt-1.5 text-sm">{item.text}</p>
                </div>
              ))}
            </div>
          </FadeInWhenVisible>
        </div>
      </div>
    </section>
  )
}

/* ────────────────────────────── WHY CHOOSE US ────────────────────────────── */

function WhyChooseUs() {
  const benefits = [
    { icon: <Trophy className="w-6 h-6" />, title: 'Líderes en resolución de problemas', desc: 'Somos la consultora Nº1 en resolución de problemas en el país. Nuestra experiencia nos permite identificar y solucionar las situaciones más complejas de forma eficaz.' },
    { icon: <Handshake className="w-6 h-6" />, title: 'Acompañamiento integral', desc: 'Estamos con usted de principio a fin, desde el diagnóstico hasta el cierre de hallazgos y la mejora continua de sus procesos.' },
    { icon: <Cog className="w-6 h-6" />, title: 'Soluciones adaptadas', desc: 'Cada empresa es única. Diseñamos estrategias personalizadas que se ajustan a su industria, tamaño y necesidades específicas.' },
    { icon: <Search className="w-6 h-6" />, title: 'Enfoque técnico, legal y preventivo', desc: 'Nuestras recomendaciones se fundamentan en la normativa vigente, las mejores prácticas y una visión preventiva que anticipa riesgos.' },
    { icon: <Award className="w-6 h-6" />, title: 'Más de 15 años de experiencia', desc: 'Contamos con más de 15 años de experiencia comprobada en la implementación y auditoría de normas ISO y sistemas de gestión empresarial.' },
    { icon: <Building2 className="w-6 h-6" />, title: 'Experiencia multisectorial', desc: 'Hemos acompañado exitosamente a empresas de servicios hoteleros, petroleros, ambientales, catering, software y más, entendiendo las particularidades de cada sector.' },
    { icon: <FileText className="w-6 h-6" />, title: 'Documentación lista para auditoría', desc: 'Elaboramos documentos técnicos profesionales que cumplen con los requisitos de organismos de certificación y control.' },
    { icon: <GraduationCap className="w-6 h-6" />, title: 'Capacitación práctica', desc: 'Nuestras capacitaciones son dinámicas, aplicables y diseñadas para que su personal asimile conocimientos de forma efectiva.' },
    { icon: <TrendingUp className="w-6 h-6" />, title: 'Seguimiento continuo', desc: 'No nos limitamos a entregar documentos. Acompañamos la implementación y verificamos que los resultados sean sostenibles.' },
    { icon: <Landmark className="w-6 h-6" />, title: 'Apoyo ante organismos de control', desc: 'Lo asesoramos y acompañamos frente al Ministerio del Trabajo y otros organismos para evitar observaciones y sanciones.' },
    { icon: <Leaf className="w-6 h-6" />, title: 'Mejora continua y reducción de riesgos', desc: 'Promovemos la cultura de mejora permanente como eje para reducir riesgos, optimizar procesos y alcanzar la excelencia operativa.' },
  ]

  return (
    <section className="py-20 lg:py-28 bg-[#1e3a5f] relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-[#1e3a5f] via-[#0f2640] to-[#1e3a5f]" />
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#2d8a4e]/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-[#2d8a4e]/5 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <FadeInWhenVisible>
          <div className="text-center mb-16">
            <span className="inline-flex items-center gap-2 text-[#4ade80] font-semibold text-sm uppercase tracking-wider mb-4">
              <Star className="w-4 h-4" />
              Nuestras fortalezas
            </span>
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">
              ¿Por qué elegir CONCASIA?
            </h2>
            <p className="text-white/70 text-lg max-w-3xl mx-auto leading-relaxed">
              Nuestro enfoque integral, técnico y humano nos diferencia. No solo entregamos documentos, sino que caminamos con usted hacia el cumplimiento normativo, la protección de sus trabajadores y la excelencia operativa.
            </p>
          </div>
        </FadeInWhenVisible>

        <StaggerContainer className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {benefits.map((b) => (
            <StaggerItem key={b.title}>
              <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all duration-300 group h-full">
                <div className="w-12 h-12 bg-[#2d8a4e]/20 text-[#4ade80] rounded-xl flex items-center justify-center mb-4 group-hover:bg-[#2d8a4e] group-hover:text-white transition-colors duration-300">
                  {b.icon}
                </div>
                <h3 className="text-lg font-bold text-white mb-2">{b.title}</h3>
                <p className="text-white/60 text-sm leading-relaxed">{b.desc}</p>
              </div>
            </StaggerItem>
          ))}
        </StaggerContainer>
      </div>
    </section>
  )
}

/* ────────────────────────────── METHODOLOGY ────────────────────────────── */

function Methodology() {
  const steps = [
    { num: '01', title: 'Diagnóstico inicial', desc: 'Realizamos una evaluación integral del estado actual de su empresa, identificando fortalezas, debilidades y brechas frente a la normativa aplicable.', icon: <Search className="w-5 h-5" /> },
    { num: '02', title: 'Identificación de necesidades y brechas', desc: 'Analizamos con detalle los hallazgos del diagnóstico para definir prioridades, recursos requeridos y el alcance de la intervención.', icon: <Target className="w-5 h-5" /> },
    { num: '03', title: 'Diseño del plan de intervención', desc: 'Elaboramos un plan de acción estructurado con cronograma, responsables, entregables y metas claras para cada etapa del proyecto.', icon: <ClipboardList className="w-5 h-5" /> },
    { num: '04', title: 'Elaboración de documentación técnica', desc: 'Desarrollamos toda la documentación requerida: manuales, procedimientos, matrices, instructivos, registros e indicadores de gestión.', icon: <PenTool className="w-5 h-5" /> },
    { num: '05', title: 'Implementación y capacitación', desc: 'Ejecutamos el plan junto con su equipo, capacitamos al personal y verificamos que cada proceso funcione conforme a lo establecido.', icon: <Wrench className="w-5 h-5" /> },
    { num: '06', title: 'Auditoría interna o verificación', desc: 'Realizamos una auditoría interna completa para evaluar el cumplimiento, detectar hallazgos y verificar la eficacia de la implementación.', icon: <ClipboardCheck className="w-5 h-5" /> },
    { num: '07', title: 'Corrección de hallazgos', desc: 'Atendemos y cerramos cada hallazgo identificado con acciones correctivas efectivas, documentadas y verificables.', icon: <CheckSquare className="w-5 h-5" /> },
    { num: '08', title: 'Seguimiento y mejora continua', desc: 'Monitoreamos los indicadores, realizamos seguimiento periódico y promovemos la mejora continua para sostener los resultados alcanzados.', icon: <TrendingUp className="w-5 h-5" /> },
  ]

  return (
    <section className="py-20 lg:py-28 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <FadeInWhenVisible>
          <div className="text-center mb-16">
            <span className="inline-flex items-center gap-2 text-[#2d8a4e] font-semibold text-sm uppercase tracking-wider mb-4">
              <Cog className="w-4 h-4" />
              Nuestra metodología
            </span>
            <h2 className="text-3xl lg:text-4xl font-bold text-[#1e3a5f] mb-6">
              Un proceso estructurado para resultados reales
            </h2>
            <p className="text-gray-600 text-lg max-w-3xl mx-auto leading-relaxed">
              Nuestra metodología de trabajo garantiza que cada intervención sea ordenada, medible y alineada con los objetivos de su empresa. Trabajamos paso a paso para asegurar el cumplimiento normativo y la mejora sostenida de sus procesos.
            </p>
          </div>
        </FadeInWhenVisible>

        <StaggerContainer className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((step) => (
            <StaggerItem key={step.num}>
              <div className="relative bg-white border border-gray-100 rounded-2xl p-6 hover:shadow-xl hover:border-[#2d8a4e]/20 transition-all duration-300 group h-full">
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-3xl font-black text-[#2d8a4e]/15 group-hover:text-[#2d8a4e]/30 transition-colors">
                    {step.num}
                  </span>
                  <div className="w-10 h-10 bg-[#2d8a4e]/10 text-[#2d8a4e] rounded-lg flex items-center justify-center group-hover:bg-[#2d8a4e] group-hover:text-white transition-colors duration-300">
                    {step.icon}
                  </div>
                </div>
                <h3 className="text-lg font-bold text-[#1e3a5f] mb-2">{step.title}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{step.desc}</p>
              </div>
            </StaggerItem>
          ))}
        </StaggerContainer>
      </div>
    </section>
  )
}

/* ────────────────────────────── SECTORS ────────────────────────────── */

function Sectors() {
  const sectors = [
    { icon: <UtensilsCrossed className="w-7 h-7" />, name: 'Empresas de alimentos' },
    { icon: <Store className="w-7 h-7" />, name: 'Restaurantes' },
    { icon: <Briefcase className="w-7 h-7" />, name: 'Catering industrial' },
    { icon: <Factory className="w-7 h-7" />, name: 'Plantas procesadoras' },
    { icon: <Building2 className="w-7 h-7" />, name: 'Servicios hoteleros' },
    { icon: <Flame className="w-7 h-7" />, name: 'Empresas petroleras' },
    { icon: <Droplets className="w-7 h-7" />, name: 'Empresas ambientales' },
    { icon: <Monitor className="w-7 h-7" />, name: 'Empresas de software' },
    { icon: <School className="w-7 h-7" />, name: 'Instituciones educativas' },
    { icon: <Hospital className="w-7 h-7" />, name: 'Clínicas y centros médicos' },
    { icon: <HardHat className="w-7 h-7" />, name: 'Industrias' },
    { icon: <Landmark className="w-7 h-7" />, name: 'Empresas públicas y privadas' },
    { icon: <Gavel className="w-7 h-7" />, name: 'Organizaciones ante el Ministerio del Trabajo' },
  ]

  return (
    <section className="py-20 lg:py-28 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <FadeInWhenVisible>
          <div className="text-center mb-16">
            <span className="inline-flex items-center gap-2 text-[#2d8a4e] font-semibold text-sm uppercase tracking-wider mb-4">
              <Building2 className="w-4 h-4" />
              Sectores que atendemos
            </span>
            <h2 className="text-3xl lg:text-4xl font-bold text-[#1e3a5f] mb-6">
              Soluciones para todos los sectores productivos
            </h2>
            <p className="text-gray-600 text-lg max-w-3xl mx-auto leading-relaxed">
              Brindamos servicios de consultoría, auditoría y capacitación a empresas de diversos sectores económicos. Cualquier organización que necesite cumplir la normativa, proteger a sus trabajadores y mejorar sus procesos puede confiar en CONCASIA.
            </p>
          </div>
        </FadeInWhenVisible>

        <StaggerContainer className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {sectors.map((s) => (
            <StaggerItem key={s.name}>
              <div className="bg-white border border-gray-100 rounded-xl p-5 text-center hover:shadow-lg hover:border-[#2d8a4e]/30 transition-all duration-300 group cursor-default">
                <div className="w-14 h-14 bg-[#1e3a5f]/5 text-[#1e3a5f] rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:bg-[#1e3a5f] group-hover:text-white transition-colors duration-300">
                  {s.icon}
                </div>
                <h4 className="text-sm font-semibold text-gray-700 group-hover:text-[#1e3a5f] transition-colors">{s.name}</h4>
              </div>
            </StaggerItem>
          ))}
        </StaggerContainer>
      </div>
    </section>
  )
}

/* ────────────────────────────── CTA ────────────────────────────── */

function CTA() {
  return (
    <section className="py-20 lg:py-28 bg-gradient-to-br from-[#1e3a5f] via-[#0f2640] to-[#2d8a4e] relative overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-10 left-10 w-72 h-72 bg-[#2d8a4e]/20 rounded-full blur-3xl" />
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-white/5 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <FadeInWhenVisible>
          <AlertCircle className="w-14 h-14 text-[#4ade80] mx-auto mb-6" />
          <h2 className="text-3xl lg:text-5xl font-bold text-white mb-6 leading-tight">
            ¿Su empresa está preparada para una auditoría?
          </h2>
          <p className="text-white/80 text-lg lg:text-xl leading-relaxed mb-10 max-w-3xl mx-auto">
            Evite sanciones, mejore sus procesos y proteja a su equipo con el acompañamiento técnico de CONCASIA. Nuestros expertos lo ayudan a cumplir la normativa, implementar sistemas de gestión y estar siempre un paso adelante ante cualquier inspección o auditoría.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#contacto"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-[#2d8a4e] hover:bg-[#1e6b38] text-white font-semibold rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl text-base"
            >
              <Phone className="w-5 h-5" />
              Solicitar asesoría
            </a>
            <a
              href="#contacto"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white/10 hover:bg-white/20 backdrop-blur-sm border border-white/30 text-white font-semibold rounded-xl transition-all duration-200 text-base"
            >
              <ClipboardCheck className="w-5 h-5" />
              Agendar diagnóstico
            </a>
            <a
              href="https://wa.me/593985801065"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-[#25d366] hover:bg-[#128c7e] text-white font-semibold rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl text-base"
            >
              <MessageCircle className="w-5 h-5" />
              Contactar por WhatsApp
            </a>
          </div>
        </FadeInWhenVisible>
      </div>
    </section>
  )
}

/* ────────────────────────────── FAQ ────────────────────────────── */

function FAQ() {
  const faqs = [
    {
      q: '¿Qué es ISO 9001 y por qué es importante para mi empresa?',
      a: 'ISO 9001 es la norma internacional que establece los requisitos para un sistema de gestión de la calidad. Su implementación permite a las organizaciones demostrar su capacidad para proporcionar productos y servicios que cumplen con los requisitos del cliente y los reglamentos aplicables, al tiempo que busca aumentar la satisfacción del cliente mediante la mejora continua del sistema. Contar con la certificación ISO 9001 no solo mejora los procesos internos y la eficiencia operativa, sino que también fortalece la credibilidad de su empresa ante clientes, proveedores y organismos de control, abriendo puertas a nuevos mercados y oportunidades de negocio.',
    },
    {
      q: '¿Por qué implementar HACCP en mi negocio de alimentos?',
      a: 'HACCP (Análisis de Peligros y Puntos Críticos de Control) es un sistema preventivo reconocido internacionalmente que identifica, evalúa y controla los peligros significativos para la inocuidad de los alimentos. Su implementación es fundamental para restaurantes, plantas procesadoras, comedores institucionales y cualquier empresa que manipule alimentos, ya que permite prevenir la contaminación física, química y biológica antes de que el producto llegue al consumidor final. Además, muchas normativas sanitarias exigen su implementación, y contar con un sistema HACCP debidamente documentado demuestra compromiso con la seguridad alimentaria y reduce significativamente el riesgo de incidentes, sanciones y pérdida de reputación.',
    },
    {
      q: '¿Qué empresas necesitan un reglamento interno de higiene y seguridad?',
      a: 'Según la legislación laboral vigente, todas las empresas que tengan uno o más trabajadores están obligadas a contar con un reglamento interno de higiene y seguridad laboral. Este documento establece las normas, procedimientos y obligaciones tanto del empleador como de los trabajadores en materia de prevención de riesgos y seguridad en el trabajo. Su ausencia puede acarrear sanciones administrativas y multas por parte del Ministerio del Trabajo. En CONCASIA le ayudamos a elaborar un reglamento completo, actualizado y adaptado a las actividades específicas de su empresa.',
    },
    {
      q: '¿Qué incluye un plan de emergencia y contingencia?',
      a: 'Un plan de emergencia y contingencia es un documento técnico que establece las acciones, procedimientos y recursos necesarios para prevenir, responder y recuperarse ante situaciones de emergencia como incendios, sismos, derrames químicos, inundaciones u otras amenazas. Incluye la identificación de riesgos, la organización de brigadas de emergencia, los procedimientos de evacuación, los puntos de reunión, los protocolos de comunicación, la señalización de seguridad y los simulacros periódicos. Un plan bien diseñado protege la vida de los trabajadores, minimiza daños a la infraestructura y demuestra cumplimiento legal ante las autoridades competentes.',
    },
    {
      q: '¿Qué es la medicina ocupacional y en qué beneficia a mi empresa?',
      a: 'La medicina ocupacional es la especialidad médica dedicada a la prevención, diagnóstico y tratamiento de las enfermedades y accidentes derivados del trabajo. Sus beneficios para la empresa son múltiples: reduce la incidencia de enfermedades profesionales, disminuye el ausentismo laboral, mejora la productividad, garantiza el cumplimiento de las obligaciones legales del empleador y promueve un ambiente de trabajo saludable. Los servicios de medicina ocupacional incluyen evaluaciones médicas de ingreso, periódicas y de reintegro, vigilancia de la salud, gestión de exámenes de laboratorio, programas de promoción y prevención, y planes pandémicos, entre otros.',
    },
    {
      q: '¿Cómo prepararse para una auditoría del Ministerio del Trabajo?',
      a: 'La preparación para una auditoría ministerial requiere una revisión exhaustiva de toda la documentación legal y técnica de su empresa: reglamento interno de higiene y seguridad, matrices de riesgos, planes de emergencia, registros de capacitación, exámenes médicos ocupacionales, actas del comité de seguridad, programas de prevención y más. En CONCASIA realizamos una auditoría interna previa que identifica brechas y hallazgos, corregimos las no conformidades, organizamos las evidencias y lo acompañamos durante la inspección para asegurar que su empresa demuestre pleno cumplimiento y evite observaciones o sanciones.',
    },
    {
      q: '¿Por qué es importante capacitar al personal en seguridad industrial?',
      a: 'La capacitación en seguridad industrial es una obligación legal y una inversión estratégica. Un personal capacitado identifica riesgos, sigue procedimientos seguros, utiliza correctamente los equipos de protección personal y responde adecuadamente ante emergencias. Esto se traduce en menos accidentes laborales, menor rotación de personal, reducción de costos por incapacidades y multas, y una cultura organizacional que valora la seguridad. Además, los registros de capacitación son evidencia clave que los organismos de control evalúan durante inspecciones y auditorías.',
    },
    {
      q: '¿Cómo puede ayudar CONCASIA a evitar sanciones de organismos de control?',
      a: 'CONCASIA ayuda a su empresa a evitar sanciones mediante un enfoque integral de cumplimiento normativo. Realizamos un diagnóstico inicial que identifica todas las brechas frente a la legislación vigente, elaboramos o actualizamos la documentación requerida, implementamos los programas y planes necesarios, capacitamos a su personal y realizamos auditorías internas para verificar el cumplimiento antes de cualquier inspección. Además, brindamos acompañamiento técnico directo durante las visitas de organismos de control como el Ministerio del Trabajo, asegurando que su empresa presente las evidencias correctas y demuestre su compromiso con la seguridad y la legalidad.',
    },
  ]

  return (
    <section className="py-20 lg:py-28 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <FadeInWhenVisible>
          <div className="text-center mb-16">
            <span className="inline-flex items-center gap-2 text-[#2d8a4e] font-semibold text-sm uppercase tracking-wider mb-4">
              <BookOpen className="w-4 h-4" />
              Preguntas frecuentes
            </span>
            <h2 className="text-3xl lg:text-4xl font-bold text-[#1e3a5f] mb-6">
              Resolvemos sus dudas
            </h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto leading-relaxed">
              Encuentre respuestas a las consultas más habituales sobre sistemas de gestión, seguridad ocupacional, inocuidad alimentaria y nuestros servicios.
            </p>
          </div>
        </FadeInWhenVisible>

        <FadeInWhenVisible delay={0.2}>
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, idx) => (
              <AccordionItem
                key={idx}
                value={`faq-${idx}`}
                className="bg-gray-50 border border-gray-100 rounded-xl px-6 data-[state=open]:bg-white data-[state=open]:shadow-lg data-[state=open]:border-[#2d8a4e]/20 transition-all duration-300"
              >
                <AccordionTrigger className="text-left text-[#1e3a5f] font-semibold hover:text-[#2d8a4e] py-5 text-base">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="text-gray-600 leading-relaxed pb-5">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </FadeInWhenVisible>
      </div>
    </section>
  )
}

/* ────────────────────────────── CONTACT ────────────────────────────── */

function Contact() {
  const [formData, setFormData] = useState({
    nombre: '',
    empresa: '',
    cargo: '',
    telefono: '',
    correo: '',
    servicio: '',
    mensaje: '',
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsSubmitting(false)
    setSubmitted(true)
    setTimeout(() => setSubmitted(false), 5000)
  }

  return (
    <section id="contacto" className="py-20 lg:py-28 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <FadeInWhenVisible>
          <div className="text-center mb-16">
            <span className="inline-flex items-center gap-2 text-[#2d8a4e] font-semibold text-sm uppercase tracking-wider mb-4">
              <Phone className="w-4 h-4" />
              Contacto
            </span>
            <h2 className="text-3xl lg:text-4xl font-bold text-[#1e3a5f] mb-6">
              Estamos listos para ayudarle
            </h2>
            <p className="text-gray-600 text-lg max-w-3xl mx-auto leading-relaxed">
              Complete el formulario y un asesor especializado se pondrá en contacto con usted a la brevedad. También puede comunicarse directamente por teléfono, WhatsApp o correo electrónico.
            </p>
          </div>
        </FadeInWhenVisible>

        <div className="grid lg:grid-cols-5 gap-8 lg:gap-12">
          {/* Contact Info */}
          <FadeInWhenVisible direction="left" className="lg:col-span-2">
            <div className="bg-[#1e3a5f] rounded-2xl p-8 lg:p-10 text-white h-full">
              <h3 className="text-2xl font-bold mb-8">Información de contacto</h3>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center shrink-0">
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">CONCASIA</h4>
                    <p className="text-white/70 text-sm">Consultoría en Sistemas de Gestión, Seguridad y Salud Ocupacional</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center shrink-0">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Teléfonos</h4>
                    <p className="text-white/70 text-sm">0985801065</p>
                    <p className="text-white/70 text-sm">0990580696</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-[#25d366] rounded-lg flex items-center justify-center shrink-0">
                    <MessageCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">WhatsApp</h4>
                    <a href="https://wa.me/593985801065" target="_blank" rel="noopener noreferrer" className="text-white/70 text-sm hover:text-[#4ade80] transition-colors block">
                      0985801065
                    </a>
                    <a href="https://wa.me/593990580696" target="_blank" rel="noopener noreferrer" className="text-white/70 text-sm hover:text-[#4ade80] transition-colors block">
                      0990580696
                    </a>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center shrink-0">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Correos electrónicos</h4>
                    <a href="mailto:ing_iselapilavallejo@yahoo.es" className="text-white/70 text-sm hover:text-[#4ade80] transition-colors block">
                      ing_iselapilavallejo@yahoo.es
                    </a>
                    <a href="mailto:marcelomartinezgg@yahoo.com" className="text-white/70 text-sm hover:text-[#4ade80] transition-colors block">
                      marcelomartinezgg@yahoo.com
                    </a>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Dirección</h4>
                    <p className="text-white/70 text-sm">Quito, Ecuador</p>
                  </div>
                </div>
              </div>
            </div>
          </FadeInWhenVisible>

          {/* Form */}
          <FadeInWhenVisible direction="right" delay={0.2} className="lg:col-span-3">
            <div className="bg-white rounded-2xl p-8 lg:p-10 border border-gray-100 shadow-sm">
              {submitted ? (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-[#2d8a4e]/10 text-[#2d8a4e] rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="text-2xl font-bold text-[#1e3a5f] mb-2">Mensaje enviado</h3>
                  <p className="text-gray-600">Gracias por contactarnos. Un asesor se comunicará con usted próximamente.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <Label htmlFor="nombre" className="text-sm font-medium text-gray-700 mb-1.5 block">
                        Nombre completo *
                      </Label>
                      <Input
                        id="nombre"
                        required
                        placeholder="Su nombre"
                        value={formData.nombre}
                        onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                        className="h-11"
                      />
                    </div>
                    <div>
                      <Label htmlFor="empresa" className="text-sm font-medium text-gray-700 mb-1.5 block">
                        Empresa *
                      </Label>
                      <Input
                        id="empresa"
                        required
                        placeholder="Nombre de su empresa"
                        value={formData.empresa}
                        onChange={(e) => setFormData({ ...formData, empresa: e.target.value })}
                        className="h-11"
                      />
                    </div>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <Label htmlFor="cargo" className="text-sm font-medium text-gray-700 mb-1.5 block">
                        Cargo
                      </Label>
                      <Input
                        id="cargo"
                        placeholder="Su cargo en la empresa"
                        value={formData.cargo}
                        onChange={(e) => setFormData({ ...formData, cargo: e.target.value })}
                        className="h-11"
                      />
                    </div>
                    <div>
                      <Label htmlFor="telefono" className="text-sm font-medium text-gray-700 mb-1.5 block">
                        Teléfono *
                      </Label>
                      <Input
                        id="telefono"
                        required
                        type="tel"
                        placeholder="0985801065"
                        value={formData.telefono}
                        onChange={(e) => setFormData({ ...formData, telefono: e.target.value })}
                        className="h-11"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="correo" className="text-sm font-medium text-gray-700 mb-1.5 block">
                      Correo electrónico *
                    </Label>
                    <Input
                      id="correo"
                      required
                      type="email"
                      placeholder="correo@empresa.com"
                      value={formData.correo}
                      onChange={(e) => setFormData({ ...formData, correo: e.target.value })}
                      className="h-11"
                    />
                  </div>
                  <div>
                    <Label htmlFor="servicio" className="text-sm font-medium text-gray-700 mb-1.5 block">
                      Servicio de interés
                    </Label>
                    <Select
                      value={formData.servicio}
                      onValueChange={(value) => setFormData({ ...formData, servicio: value })}
                    >
                      <SelectTrigger className="h-11">
                        <SelectValue placeholder="Seleccione un servicio" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sistemas-gestion">Sistemas de Gestión y Calidad</SelectItem>
                        <SelectItem value="inocuidad">Inocuidad Alimentaria</SelectItem>
                        <SelectItem value="seguridad-salud">Seguridad y Salud Ocupacional</SelectItem>
                        <SelectItem value="organismos">Gestión ante Organismos de Control</SelectItem>
                        <SelectItem value="medicina">Medicina Ocupacional</SelectItem>
                        <SelectItem value="capacitaciones">Capacitación Empresarial</SelectItem>
                        <SelectItem value="otro">Otro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="mensaje" className="text-sm font-medium text-gray-700 mb-1.5 block">
                      Mensaje
                    </Label>
                    <Textarea
                      id="mensaje"
                      placeholder="Cuéntenos sobre las necesidades de su empresa..."
                      rows={4}
                      value={formData.mensaje}
                      onChange={(e) => setFormData({ ...formData, mensaje: e.target.value })}
                    />
                  </div>
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full h-12 bg-[#2d8a4e] hover:bg-[#1e6b38] text-white font-semibold text-base"
                  >
                    {isSubmitting ? (
                      <span className="flex items-center gap-2">
                        <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg>
                        Enviando...
                      </span>
                    ) : (
                      <span className="flex items-center gap-2">
                        <ArrowRight className="w-5 h-5" />
                        Enviar solicitud de asesoría
                      </span>
                    )}
                  </Button>
                </form>
              )}
            </div>
          </FadeInWhenVisible>
        </div>
      </div>
    </section>
  )
}

/* ────────────────────────────── FOOTER ────────────────────────────── */

function Footer() {
  const [showScrollTop, setShowScrollTop] = useState(false)

  useEffect(() => {
    const handleScroll = () => setShowScrollTop(window.scrollY > 600)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <footer className="bg-[#0f172a] text-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="lg:col-span-1">
            <img
              src="/concasia-logo.png"
              alt="CONCASIA"
              className="h-10 w-auto mb-4 brightness-0 invert"
            />
            <p className="text-gray-400 text-sm leading-relaxed mb-6">
              Consultoría, capacitación, auditoría y acompañamiento especializado en sistemas de gestión, seguridad y salud ocupacional, inocuidad alimentaria y medicina ocupacional.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-white mb-4">Navegación</h4>
            <ul className="space-y-2.5">
              {[
                { href: '#inicio', label: 'Inicio' },
                { href: '#nosotros', label: 'Nosotros' },
                { href: '#servicios', label: 'Servicios' },
                { href: '#contacto', label: 'Contacto' },
              ].map((link) => (
                <li key={link.href}>
                  <a href={link.href} className="text-gray-400 hover:text-[#4ade80] text-sm transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-semibold text-white mb-4">Servicios</h4>
            <ul className="space-y-2.5">
              {[
                { href: '#sistemas-gestion', label: 'Sistemas de Gestión' },
                { href: '#inocuidad', label: 'Inocuidad Alimentaria' },
                { href: '#seguridad-salud', label: 'Seguridad y Salud' },
                { href: '#organismos', label: 'Organismos de Control' },
                { href: '#medicina', label: 'Medicina Ocupacional' },
                { href: '#capacitaciones', label: 'Capacitaciones' },
              ].map((link) => (
                <li key={link.href}>
                  <a href={link.href} className="text-gray-400 hover:text-[#4ade80] text-sm transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold text-white mb-4">Contacto</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-3 text-gray-400 text-sm">
                <Phone className="w-4 h-4 text-[#4ade80] shrink-0" />
                0985801065 / 0990580696
              </li>
              <li className="flex items-center gap-3 text-sm">
                <MessageCircle className="w-4 h-4 text-[#25d366] shrink-0" />
                <a href="https://wa.me/593985801065" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-[#4ade80] transition-colors">
                  WhatsApp: 0985801065
                </a>
              </li>
              <li className="flex items-center gap-3 text-sm">
                <MessageCircle className="w-4 h-4 text-[#25d366] shrink-0" />
                <a href="https://wa.me/593990580696" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-[#4ade80] transition-colors">
                  WhatsApp: 0990580696
                </a>
              </li>
              <li className="flex items-center gap-3 text-gray-400 text-sm">
                <Mail className="w-4 h-4 text-[#4ade80] shrink-0" />
                <a href="mailto:ing_iselapilavallejo@yahoo.es" className="hover:text-[#4ade80] transition-colors">ing_iselapilavallejo@yahoo.es</a>
              </li>
              <li className="flex items-center gap-3 text-gray-400 text-sm">
                <Mail className="w-4 h-4 text-[#4ade80] shrink-0" />
                <a href="mailto:marcelomartinezgg@yahoo.com" className="hover:text-[#4ade80] transition-colors">marcelomartinezgg@yahoo.com</a>
              </li>
              <li className="flex items-start gap-3 text-gray-400 text-sm">
                <MapPin className="w-4 h-4 text-[#4ade80] shrink-0 mt-0.5" />
                Quito, Ecuador
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-gray-500 text-sm">
            © {new Date().getFullYear()} CONCASIA. Todos los derechos reservados.
          </p>
          <div className="flex items-center gap-4">
            <a href="#" className="text-gray-500 hover:text-[#4ade80] text-sm transition-colors">
              Política de privacidad
            </a>
            <a href="#" className="text-gray-500 hover:text-[#4ade80] text-sm transition-colors">
              Términos de uso
            </a>
          </div>
        </div>
      </div>

      {/* WhatsApp floating button */}
      <a
        href="https://wa.me/593985801065"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-40 w-14 h-14 bg-[#25d366] hover:bg-[#128c7e] text-white rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 whatsapp-pulse"
        aria-label="Contactar por WhatsApp"
      >
        <MessageCircle className="w-7 h-7" />
      </a>

      {/* Scroll to top button */}
      {showScrollTop && (
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="fixed bottom-6 left-6 z-40 w-12 h-12 bg-[#1e3a5f] hover:bg-[#2b5a8c] text-white rounded-full flex items-center justify-center shadow-lg transition-all duration-300"
          aria-label="Volver arriba"
        >
          <ChevronUp className="w-5 h-5" />
        </button>
      )}
    </footer>
  )
}

/* ────────────────────────────── MAIN PAGE ────────────────────────────── */

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <Hero />
        <About />
        <Services />
        {services.map((service) => (
          <ServiceDetailSection key={service.id} service={service} />
        ))}
        <WhyChooseUs />
        <Methodology />
        <Sectors />
        <CTA />
        <FAQ />
        <Contact />
      </main>
      <Footer />
    </div>
  )
}

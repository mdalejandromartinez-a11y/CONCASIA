import type { Metadata } from "next";
import { Inter, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

const jakarta = Plus_Jakarta_Sans({
  variable: "--font-jakarta",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "CONCASIA | Consultoría en Sistemas de Gestión, Seguridad y Salud Ocupacional",
  description:
    "Consultoría, capacitación, auditoría y acompañamiento especializado en calidad, inocuidad alimentaria, seguridad y salud ocupacional, gestión de riesgos y medicina ocupacional. Soluciones integrales para el cumplimiento normativo de su empresa.",
  keywords: [
    "Consultoría ISO 9001",
    "Implementación ISO 9001",
    "Seguridad y salud ocupacional",
    "Medicina ocupacional",
    "Buenas Prácticas Alimenticias",
    "HACCP",
    "Gestión de riesgos laborales",
    "Planes de emergencia",
    "Reglamentos internos de higiene y seguridad",
    "Auditorías ministeriales",
    "Ministerio del Trabajo",
    "Capacitación en seguridad industrial",
    "Sistemas de gestión empresarial",
    "Inocuidad alimentaria",
    "Salud ocupacional para empresas",
    "CONCASIA",
  ],
  authors: [{ name: "CONCASIA" }],
  icons: {
    icon: "/concasia-logo.png",
  },
  openGraph: {
    title: "CONCASIA | Consultoría en Sistemas de Gestión, Seguridad y Salud Ocupacional",
    description:
      "Soluciones integrales en sistemas de gestión, seguridad laboral, inocuidad alimentaria y medicina ocupacional. Cumpla la normativa vigente con el acompañamiento técnico de CONCASIA.",
    siteName: "CONCASIA",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "CONCASIA | Consultoría en Sistemas de Gestión",
    description:
      "Soluciones integrales en sistemas de gestión, seguridad laboral, inocuidad alimentaria y medicina ocupacional.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning className="scroll-smooth">
      <body
        className={`${inter.variable} ${jakarta.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}

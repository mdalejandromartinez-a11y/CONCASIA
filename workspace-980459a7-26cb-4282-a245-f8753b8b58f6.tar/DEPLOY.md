# CONCASIA - Guía de Despliegue a www.concasia.com.ec

## Paso 1: Crear repositorio en GitHub

1. Vaya a [github.com](https://github.com) y cree una cuenta (si no tiene)
2. Cree un nuevo repositorio llamado `concasia-website`
3. No inicialice con README (ya lo tenemos)

## Paso 2: Subir el código a GitHub

Desde una terminal en su computadora:

```bash
# Clonar o descargar el proyecto
cd concasia-website

# Inicializar git
git init
git add .
git commit -m "CONCASIA - Sitio web corporativo v1.0"

# Conectar con GitHub (reemplace USUARIO por su usuario)
git remote add origin https://github.com/USUARIO/concasia-website.git
git branch -M main
git push -u origin main
```

## Paso 3: Desplegar en Vercel

1. Vaya a [vercel.com](https://vercel.com) y cree una cuenta
2. Haga clic en **"Add New Project"**
3. Seleccione su repositorio `concasia-website`
4. Vercel detectará automáticamente que es Next.js
5. Haga clic en **"Deploy"**
6. Espere 1-2 minutos y su sitio estará en línea

## Paso 4: Conectar dominio www.concasia.com.ec

### 4a. En Vercel:
1. Vaya a **Settings > Domains**
2. Agregue `concasia.com.ec`
3. Agregue `www.concasia.com.ec`
4. Vercel le mostrará los registros DNS necesarios

### 4b. En su registrador de dominios (NIC Ecuador, GoDaddy, etc.):
Agregue los siguientes registros DNS:

| Tipo  | Nombre | Valor                      |
|-------|--------|----------------------------|
| A     | @      | 76.76.21.21               |
| CNAME | www    | cname.vercel-dns.com       |

### 4c. Espere propagación DNS (5 min - 48 horas)

## Paso 5: Verificar

Una vez propagado el DNS:
- www.concasia.com.ec estará en línea
- concasia.com.ec redirigirá a www.concasia.com.ec
- Vercel automáticamente proporciona certificado SSL (HTTPS)

---

## Información de contacto configurada en el sitio:

- Teléfonos: 0985801065 / 0990580696
- WhatsApp: 0985801065 / 0990580696
- Correos: ing_iselapilavallejo@yahoo.es / marcelomartinezgg@yahoo.com
- Dirección: Quito, Ecuador
- Experiencia: +15 años
- Líderes en resolución de problemas en el país

---

## Notas importantes:

- El plan gratuito de Vercel incluye 100GB de bandwidth/mes (suficiente)
- Cada vez que haga `git push`, Vercel despliega automáticamente
- El certificado SSL se renueva automáticamente
- Para cambios futuros, solo edite el código y haga push a GitHub
